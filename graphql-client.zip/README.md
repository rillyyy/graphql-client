# GraphQL Client

- Apollo 는 Server 와 Client 제공하므로
- 참조문서 : https://www.apollographql.com/docs/react/get-started/
- `# GraphQL Client

- Apollo 는 Server 와 Client 제공하므로
- 참조문서 : https://www.apollographql.com/docs/react/get-started/
- `npm install @apollo/client graphql`

## Apollo 환경 셋팅

- index.js

```js
import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import App from "./App";
import { ApolloClient, ApolloProvider, InMemoryCache } from "@apollo/client";

// GraphQL 환경셋팅
const client = new ApolloClient({
  uri: "http://localhost:4000",
  cache: new InMemoryCache(),
});

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <ApolloProvider client={client}>
    <App />
  </ApolloProvider>
);
```

- `npm start`

## 목록 출력하기
