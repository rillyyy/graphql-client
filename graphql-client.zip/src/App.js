const List = () => {
  return <div>목록보기</div>;
};

function App() {
  return (
    <>
      <List />
    </>
  );
}

export default App;
