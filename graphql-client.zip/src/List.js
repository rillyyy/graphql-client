export const List = () => {
  return <div>목록보기</div>;
};
